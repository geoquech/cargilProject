﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Cargill_Solution.Startup))]
namespace Cargill_Solution
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
