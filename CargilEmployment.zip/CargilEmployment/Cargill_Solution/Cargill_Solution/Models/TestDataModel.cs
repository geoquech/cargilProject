﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cargill_Solution.Models
{
    public class TestDataModel
    {
        public int id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Age { get; set; }
        public string Hometown { get; set; }
        public string Job { get; set; }
    }
}