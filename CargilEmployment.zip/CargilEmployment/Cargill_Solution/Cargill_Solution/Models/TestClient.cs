﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MySql.Data.MySqlClient;
using System.Configuration;
using System.Reflection;
using System.Data;
using Newtonsoft.Json;
using System.Text;
using log4net;
using Cargill_Solution.Controllers;

namespace Cargill_Solution.Models
{
    public class TestClient
    {
        ILog log = log4net.LogManager.GetLogger(typeof(HomeController));
        public MySqlConnection connection;
        string server;
        public string database;
        public string uid;
        public string password;

        public TestClient()
        {
            Initialize();
        }

        public void Initialize()
        {
            string connectionString;
            try
            {
                this.server = ConfigurationManager.AppSettings["mySQLServer"].ToString();
                this.database = ConfigurationManager.AppSettings["database"].ToString();
                this.uid = ConfigurationManager.AppSettings["uiDatabase"].ToString();
                this.password = ConfigurationManager.AppSettings["passwordDatabase"].ToString();
                connectionString = "SERVER=" + server + ";" + "DATABASE=" +
                this.database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";
                this.connection = new MySqlConnection(connectionString);
            }
            catch (Exception ex)
            {
                
            }
        }

        public bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based 
                //on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        log.Error("Function: OpenConnection, Message Error: " + ex.Message + ", " + ex.Number + ": " + "Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        log.Error("Function: OpenConnection, Message Error: " + ex.Message + ", " + ex.Number + ": " + "Invalid username/password, please try again");
                        break;
                }
                return false;
            }
        }

        //Close connection
        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                log.Error("Function: CloseConnection, Message Error: " + ex.Message + ", " + ex.Number);
                return false;
            }
        }


        public List<DataRow> GetAllTestData()
        {
            MySqlDataReader dataReader;
            List<DataRow> dr;
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                var dt = new DataTable();
                using (var command = new MySqlCommand("GetAllTestData", connection)
                {
                    CommandType = CommandType.StoredProcedure

                })
                {
                    dataReader = command.ExecuteReader();
                    dt.Load(dataReader);
                    dr = dt.AsEnumerable().ToList();
                    dataReader.Close();

                }
                return dr;

            }
            catch (Exception ex)
            {
                string error = "Function: GetAllTestData() , Mensaje de Error:  " + ex.Message.ToString();
                log.Error(error);
                if (connection.State == ConnectionState.Open)
                {
                    this.CloseConnection();
                }
                return null;
            }
        }
        /*---------------------------------------*/
        public List<DataRow> GetPersonById(int id)
        {

            MySqlCommand cmd;
            MySqlDataReader dataReader;
            List<DataRow> dr;
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                var dt = new DataTable();
                cmd = new MySqlCommand("GetPersonByID", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("idIN", MySqlDbType.Int32).Value = id;
                dataReader = cmd.ExecuteReader();
                dt.Load(dataReader);
                dr = dt.AsEnumerable().ToList();
                dataReader.Close();
                this.CloseConnection();
                return dr;

            }
            catch (Exception ex)
            {
                string error = "Function: GetPersonById() , Mensaje de Error:  " + ex.Message.ToString();
                if (connection.State == ConnectionState.Open)
                {
                    this.CloseConnection();
                }
                log.Error(error);
                return null;
            }
        }
        /*---------------------------*/
        public int InsertarUsuario(string firstname, string lastname, string age, string hometown, string job)
        {
            MySqlCommand cmd;
            try
            {
                if (connection.State == ConnectionState.Closed)
                {
                    connection.Open();
                }
                cmd = new MySqlCommand("InsertUser", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add("firstnameIN", MySqlDbType.VarString).Value = firstname;
                cmd.Parameters.Add("lastNameIN", MySqlDbType.VarString).Value = lastname;
                cmd.Parameters.Add("ageIN", MySqlDbType.VarString).Value = age;
                cmd.Parameters.Add("hometownIN", MySqlDbType.VarString).Value = hometown;
                cmd.Parameters.Add("jobIN", MySqlDbType.VarString).Value = job;     

                var rowsAffected = Convert.ToInt32(cmd.ExecuteScalar());
                this.CloseConnection();
                return rowsAffected;
            }
            catch (Exception ex)
            {
                string error = "Function: InsertarUsuario() , Mensaje de Error:  " + ex.Message.ToString();
                log.Error(error);
                if (connection.State == ConnectionState.Open)
                {
                    this.CloseConnection();
                }
                return 2; /*---Significa que dio error*/
            }
        }




    }



}