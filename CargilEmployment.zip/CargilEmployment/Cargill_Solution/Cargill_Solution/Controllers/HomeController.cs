﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using Cargill_Solution.Models;
using log4net;

namespace Cargill_Solution.Controllers
{
    public class HomeController : Controller
    {
        TestClient MySQLConnect;
        ILog log = log4net.LogManager.GetLogger(typeof(HomeController));
        public HomeController()
        {
            this.MySQLConnect = new TestClient();
            ViewBag.Info = 0;
            ViewBag.listTest = this.MySQLConnect.GetAllTestData();
            ViewBag.Info = 0;
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult TestData()
        {
            TestDataModel test;
            List<TestDataModel> testArray;
            try
            {
                testArray = new List<TestDataModel>();
                foreach (var item in ViewBag.listTest)
                {
                    test = new TestDataModel();
                    test.id = item.ItemArray[0];
                    test.FirstName = item.ItemArray[1];
                    test.LastName = item.ItemArray[2];
                    test.Age = item.ItemArray[3];
                    test.Hometown = item.ItemArray[4];
                    test.Job = item.ItemArray[5];
                    testArray.Add(test);
                }
                return View("TestData", testArray.ToList());
            }
            catch(Exception ex)
            {
                return null;
            }
            
        }

        public ActionResult CodeReview()
        {
            return View();
        }

        public ActionResult CodeSytle()
        {
            return View();
        }


        public ActionResult SnippetA()
        {
            return View();
        }

        public ActionResult SnippetB()
        {
            return View();
        }
        public ActionResult linkStyle()
        {
            return View();
        }

        public ActionResult btnBootstrap()
        {
            return View();
        }
        public ActionResult layoutResponsive()
        {
            return View();
        }
        

        public ActionResult tableLayout()
        {
            return View();
        }

        [HttpPost]
        [OutputCache(Duration = 3600, VaryByParam = "none", Location = OutputCacheLocation.Client, NoStore = true)]
        public JsonResult InsertUser(string firstName, string lastName, string age, string hometowm, string job)
        {
            try
            {
                this.MySQLConnect.InsertarUsuario(firstName,lastName,age,hometowm,job);
                var result = Json(
                   new
                   {
                       Success = false,//success
                       StatusMessage = "Exito"
                   });
                return result;

            }
            catch(Exception ex)
            {
                var result = Json(
                   new
                   {
                       Success = false,//success
                       StatusMessage = "Error"
                   });
                return result;
            }
            return null;
        }

        [HttpPost]
        [OutputCache(Duration = 3600, VaryByParam = "none", Location = OutputCacheLocation.Client, NoStore = true)]
        public JsonResult showUser(int id)
        {
            try
            {
                ViewBag.DetalleVehiculo = this.MySQLConnect.GetPersonById(id);
                var result = Json(
                   new
                   {
                       Success = false,//success
                       StatusMessage = ViewBag.DetalleVehiculo[0].ItemArray[1] + "," + ViewBag.DetalleVehiculo[0].ItemArray[2] + "," + ViewBag.DetalleVehiculo[0].ItemArray[3] + "," + ViewBag.DetalleVehiculo[0].ItemArray[4] + "," + ViewBag.DetalleVehiculo[0].ItemArray[5]
                   });

                return result;
            }
            catch(Exception ex)
            {
                string error = "Vista: DetalleVehiculo, Mensaje de Error: " + ex.Message.ToString();
                log.Error(error);
                return null;
            }
            
        }


    }
}