function Insertar()
{
    var firstName = $('#FirstName').val();
    var lastName = $('#LastName').val();
    var age = $('#Age').val();
    var hometown = $('#Hometown').val();
    var job = $('#Job').val();

    $.ajax({
        type: "POST",
        url: "/Home/InsertUser",
        data: "{'firstName':'" + firstName + "','lastName':'" + lastName + "','age':'" + age + "','hometowm':'" + hometown + "','job':'" + job + "'}",
        contentType: 'application/json; charset=uft-8',
        dataType: "json",
        beforeSend: function () {
        },

        success: function (response) {
            
            
            alert('Inserci�n se realiz� exito')
            return false;
        },

        failure: function (response) {
            alert('Error insertar persona');
        },

        error: function (response) {
            alert('Error al cargar los datos de la persona');
        }
    });
}

$('#mySelect').on('change', function () {
    var value = $(this).val();
    


    $.ajax({
        type: "POST",
        url: "/Home/showUser",
        data: "{'id':'" + value + "'}",
        contentType: 'application/json; charset=uft-8',
        dataType: "json",
        beforeSend: function () {
        },

        success: function (response) {
            
            var DOM = response.StatusMessage.split(",");
            $('#infoFirstName').text(DOM[0]);
            $('#infoLastName').text(DOM[1]);
            $('#infoAge').text(DOM[2]);
            $('#infoHometown').text(DOM[3]);
            $('#infoJob').text(DOM[4]);
            
            return false;
        },

        failure: function (response) {
            alert('Error al cargar los datos de la persona');
        },

        error: function (response) {
            alert('Error al cargar los datos de la persona');
        }
    });



});