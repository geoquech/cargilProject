SET SQL_SAFE_UPDATES = 0;

CREATE TABLE TABLE_TEST (
     id int NOT NULL AUTO_INCREMENT PRIMARY KEY,	 
     FirstName varchar(200) NOT NULL,
	 LastName varchar(200) NOT NULL,
	 Age varchar(200) NOT NULL,
	 Hometown varchar(200) NOT NULL,
	 Job varchar(200) NOT NULL	 
);


INSERT INTO ShoppingCar.TABLE_TEST(id,FirstName,LastName,Age,Hometown,Job) values(1,'Peter','Griffin','41','Quahog','Brewery');
INSERT INTO ShoppingCar.TABLE_TEST(id,FirstName,LastName,Age,Hometown,Job) values(2,'Lois','Griffin','40','Newport','Piano Teacher');
INSERT INTO ShoppingCar.TABLE_TEST(id,FirstName,LastName,Age,Hometown,Job) values(3,'Joseph','Swanson','39','Quahog','Police Officer');
INSERT INTO ShoppingCar.TABLE_TEST(id,FirstName,LastName,Age,Hometown,Job) values(4,'Glenn','Quagmire','41','Quahog','Pilot');


DELIMITER //
CREATE PROCEDURE GetAllTestData()
	BEGIN		
		SELECT id, FirstName. LastName, Age, Hometown, Job FROM ShoppingCar.TABLE_TEST;		
	END //
DELIMITER ;  



DELIMITER //
CREATE  PROCEDURE GetPersonByID(IN idIN int(11))
BEGIN
	SELECT * FROM ShoppingCar.TABLE_TEST  WHERE id = idIN;
END //
DELIMITER ;  




/*--------------------------*/
DELIMITER //
CREATE PROCEDURE `InsertUser`(
IN firstnameIN VARCHAR(200),  
IN lastNameIN VARCHAR(200), 
IN ageIN VARCHAR(200), 
IN hometownIN VARCHAR(200), 
IN jobIN VARCHAR(200)
)
BEGIN   
		DECLARE `_rollback` BOOL DEFAULT 0;
        INSERT INTO ShoppingCar.TABLE_TEST(FirstName,LastName,Age,Hometown,Job) values(firstnameIN,lastNameIN,ageIN,hometownIN,jobIN);
	   IF `_rollback` THEN
			ROLLBACK;
		ELSE
			COMMIT;
		END IF;
   END //
DELIMITER ;